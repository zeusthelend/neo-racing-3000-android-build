package com.neo.racing;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.net.Uri;
import android.content.res.AssetManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.InputStream;
import java.io.FileNotFoundException;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class MainActivity extends Activity {
    private WebView webView;
    private NativeGamepadManager gamepads;

    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        hideSystemBars();
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(visibility -> {
            if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0 ||
                    (visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) hideSystemBars();
        });
        gamepads = new NativeGamepadManager(this);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setBackgroundColor(0xff071525);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage message) {
                android.util.Log.e("NeoRacingWeb", message.message() + " (" + message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            private WebResourceResponse serveLocalAsset(String url) {
                try {
                    Uri uri = Uri.parse(url);
                    if (!"appassets.androidplatform.net".equals(uri.getHost())) return null;
                    String path = Uri.decode(uri.getPath());
                    if (path == null || !path.startsWith("/assets/")) return forbidden();
                    String assetPath = path.substring("/assets/".length());
                    if (assetPath.contains("..") || assetPath.startsWith("/")) return forbidden();
                    String mime = "application/octet-stream";
                    if (assetPath.endsWith(".html")) mime = "text/html";
                    else if (assetPath.endsWith(".js")) mime = "application/javascript";
                    else if (assetPath.endsWith(".css")) mime = "text/css";
                    else if (assetPath.endsWith(".json")) mime = "application/json";
                    else if (assetPath.endsWith(".svg")) mime = "image/svg+xml";
                    else if (assetPath.endsWith(".png")) mime = "image/png";
                    else if (assetPath.endsWith(".jpg") || assetPath.endsWith(".jpeg")) mime = "image/jpeg";
                    else if (assetPath.endsWith(".gz")) mime = "application/gzip";
                    return new WebResourceResponse(mime, "UTF-8", getAssets().open(assetPath, AssetManager.ACCESS_STREAMING));
                } catch (FileNotFoundException e) {
                    android.util.Log.e("NeoRacingWeb", "Local game asset not found: " + url, e);
                    return response("text/plain", 404, "Not Found", "Game asset not found");
                } catch (Exception e) {
                    android.util.Log.e("NeoRacingWeb", "Local game asset failed: " + url, e);
                    return response("text/plain", 500, "Asset Error", "Game asset error");
                }
            }
            private WebResourceResponse forbidden() { return response("text/plain", 403, "Forbidden", "Forbidden"); }
            private WebResourceResponse response(String mime, int code, String reason, String body) {
                return new WebResourceResponse(mime, "UTF-8", code, reason, null,
                        new java.io.ByteArrayInputStream(body.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveLocalAsset(request.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return serveLocalAsset(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("https://appassets.androidplatform.net/assets/www/");
            }
        });
        webView.addJavascriptInterface(new GamepadJsBridge(gamepads), "AndroidGamepad");
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    private boolean controllerKey(KeyEvent event) {
        // Do not pre-filter by SOURCE_GAMEPAD: several OTG/HID controllers are mislabeled
        // by Android as a mouse/keyboard. NativeGamepadManager validates external gamepads
        // before consuming a button, so ordinary phone and keyboard input remains untouched.
        return gamepads != null && gamepads.handleKeyEvent(event);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (controllerKey(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (gamepads != null && gamepads.handleMotionEvent(event)) return true;
        return super.dispatchGenericMotionEvent(event);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        // Android may expose generic OTG controllers as "HID Mouse" and route the
        // face/action buttons as mouse ACTION_DOWN/UP. Convert those external-device
        // button events to gamepad buttons, but let ordinary screen touches reach UI.
        if (gamepads != null && gamepads.handlePointerButtonTouch(event)) return true;
        return super.dispatchTouchEvent(event);
    }

    @Override protected void onResume() { super.onResume(); hideSystemBars(); if (webView != null) webView.onResume(); }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }
    @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape'}))", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (gamepads != null) gamepads.dispose();
        if (webView != null) { webView.removeJavascriptInterface("AndroidGamepad"); webView.destroy(); }
        super.onDestroy();
    }
}
