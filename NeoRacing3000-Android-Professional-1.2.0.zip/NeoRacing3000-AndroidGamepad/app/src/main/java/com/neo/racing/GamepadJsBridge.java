package com.neo.racing;

import android.webkit.JavascriptInterface;

/** Restricted bridge to structured gamepad input only; no arbitrary Java method calls. */
public final class GamepadJsBridge {
    private final NativeGamepadManager manager;
    public GamepadJsBridge(NativeGamepadManager manager) { this.manager = manager; }
    @JavascriptInterface public String getGamepadsJson() { return manager.getGamepadsJson(); }
    @JavascriptInterface public String getDevicesJson() { return manager.getDevicesJson(); }
    @JavascriptInterface public boolean assignDevice(int player, int deviceId) { return manager.assignDevice(player, deviceId); }
    @JavascriptInterface public boolean vibratePlayer(int player) { return manager.vibratePlayer(player); }
    @JavascriptInterface public String loadProfile(int player) { return manager.loadProfile(player); }
    @JavascriptInterface public boolean saveProfile(int player, String json) { return manager.saveProfile(player, json); }
    @JavascriptInterface public void resetProfile(int player) { manager.resetProfile(player); }
    @JavascriptInterface public boolean isAvailable() { return true; }
}
