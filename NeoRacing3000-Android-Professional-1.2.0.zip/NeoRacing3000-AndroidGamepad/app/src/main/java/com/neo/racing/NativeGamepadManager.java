package com.neo.racing;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.VibrationEffect;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Native USB/Bluetooth gamepad collector. Each physical device has an isolated state. */
public final class NativeGamepadManager implements InputManager.InputDeviceListener {
    private static final String PREFS = "nxr_native_gamepad";
    private static final String P1 = "player1_descriptor";
    private static final String P2 = "player2_descriptor";
    private static final String PROFILE1 = "player1_profile";
    private static final String PROFILE2 = "player2_profile";
    private static final int BUTTON_COUNT = 32;
    private static final int AXIS_COUNT = 8;

    private final Context context;
    private final InputManager inputManager;
    private final SharedPreferences prefs;
    private final Map<Integer, PadState> pads = new HashMap<>();
    private final Map<Integer, String> assignment = new HashMap<>();
    private final Object lock = new Object();
    private long lastScanAt = 0L;
    private long lastJsonAt = 0L;
    private String gamepadsJsonCache = "[]";

    private static final class PadState {
        final int deviceId;
        final String descriptor;
        final String name;
        final float[] axes = new float[AXIS_COUNT];
        final float[] buttons = new float[BUTTON_COUNT];
        final float[] keyButtons = new float[BUTTON_COUNT];
        final float[] pointerButtons = new float[BUTTON_COUNT];
        long timestamp;
        PadState(InputDevice d) {
            deviceId = d.getId();
            String rawDescriptor = safe(d.getDescriptor());
            name = safe(d.getName());
            // Some generic HID drivers return an empty descriptor; keep such devices distinct.
            descriptor = rawDescriptor.isEmpty() ? "android-id:" + d.getId() + ":" + name : rawDescriptor;
            timestamp = android.os.SystemClock.uptimeMillis();
        }
    }

    public NativeGamepadManager(Context context) {
        this.context = context.getApplicationContext();
        prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        inputManager = (InputManager) this.context.getSystemService(Context.INPUT_SERVICE);
        if (inputManager != null) inputManager.registerInputDeviceListener(this, new android.os.Handler(android.os.Looper.getMainLooper()));
        synchronized (lock) { refreshDevicesLocked(); }
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static String prefKey(int player) { return player == 0 ? P1 : P2; }

    private boolean isController(InputDevice d) {
        if (d == null) return false;
        int sources = d.getSources();
        if ((sources & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (sources & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return true;
        // Several generic OTG pads are mislabeled by Android as HID Mouse or keyboard.
        // Accept only external devices with controller-like extra axes or gamepad button keys.
        boolean external = d.getId() != 0;
        if (Build.VERSION.SDK_INT >= 29) external = d.isExternal();
        if (!external) return false;
        int motionSources = InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_MOUSE;
        int extraAxes = 0;
        int[] axes = { MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY,
                MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER };
        for (int axis : axes) if (d.getMotionRange(axis) != null) extraAxes++;
        boolean mouseSource = (sources & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE;
        if (d.getMotionRange(MotionEvent.AXIS_X) != null && d.getMotionRange(MotionEvent.AXIS_Y) != null
                && (extraAxes > 0 || mouseSource)) return true;
        int[][] groups = {{KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y},
                {KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2},
                {KeyEvent.KEYCODE_BUTTON_1, KeyEvent.KEYCODE_BUTTON_2, KeyEvent.KEYCODE_BUTTON_3, KeyEvent.KEYCODE_BUTTON_4,
                        KeyEvent.KEYCODE_BUTTON_5, KeyEvent.KEYCODE_BUTTON_6, KeyEvent.KEYCODE_BUTTON_7, KeyEvent.KEYCODE_BUTTON_8,
                        KeyEvent.KEYCODE_BUTTON_9, KeyEvent.KEYCODE_BUTTON_10, KeyEvent.KEYCODE_BUTTON_11, KeyEvent.KEYCODE_BUTTON_12,
                        KeyEvent.KEYCODE_BUTTON_13, KeyEvent.KEYCODE_BUTTON_14, KeyEvent.KEYCODE_BUTTON_15, KeyEvent.KEYCODE_BUTTON_16}};
        for (int[] group : groups) {
            boolean[] has = d.hasKeys(group);
            for (boolean value : has) if (value) return true;
        }
        return false;
    }

    private void refreshDevicesLocked() {
        if (inputManager == null) return;
        long now = android.os.SystemClock.uptimeMillis();
        // Device add/remove/change listeners keep this current; cap full enumeration in frame polling.
        if (now - lastScanAt < 350L) { assignUnclaimedLocked(); return; }
        lastScanAt = now;
        Set<Integer> live = new HashSet<>();
        for (int id : inputManager.getInputDeviceIds()) {
            InputDevice d = inputManager.getInputDevice(id);
            if (!isController(d)) continue;
            live.add(id);
            PadState prior = pads.get(id);
            if (prior == null || !prior.descriptor.equals(safe(d.getDescriptor())) || !prior.name.equals(safe(d.getName()))) {
                PadState next = new PadState(d);
                if (prior != null) {
                    System.arraycopy(prior.axes, 0, next.axes, 0, AXIS_COUNT);
                    System.arraycopy(prior.buttons, 0, next.buttons, 0, BUTTON_COUNT);
                    System.arraycopy(prior.keyButtons, 0, next.keyButtons, 0, BUTTON_COUNT);
                    System.arraycopy(prior.pointerButtons, 0, next.pointerButtons, 0, BUTTON_COUNT);
                }
                pads.put(id, next);
            }
        }
        pads.keySet().removeIf(id -> !live.contains(id));
        assignUnclaimedLocked();
    }

    private List<PadState> orderedLocked() {
        ArrayList<PadState> out = new ArrayList<>(pads.values());
        Collections.sort(out, Comparator.comparing((PadState p) -> p.descriptor).thenComparingInt(p -> p.deviceId));
        return out;
    }

    /** Assigns first two newly seen descriptors once; saved descriptors survive reconnects. */
    private void assignUnclaimedLocked() {
        String p1 = prefs.getString(P1, ""), p2 = prefs.getString(P2, "");
        List<PadState> ordered = orderedLocked();
        for (PadState p : ordered) {
            if (p.descriptor.equals(p1) || p.descriptor.equals(p2)) continue;
            if (p1.isEmpty()) { p1 = p.descriptor; prefs.edit().putString(P1, p1).apply(); }
            else if (p2.isEmpty()) { p2 = p.descriptor; prefs.edit().putString(P2, p2).apply(); }
        }
        assignment.put(0, p1); assignment.put(1, p2);
    }

    public boolean handleKeyEvent(KeyEvent event) {
        if (event == null || event.getAction() == KeyEvent.ACTION_MULTIPLE) return false;
        InputDevice d = event.getDevice();
        if (!isController(d)) return false;
        int index = buttonIndex(event.getKeyCode());
        if (index < 0) return false;
        synchronized (lock) {
            refreshDevicesLocked();
            PadState p = pads.get(d.getId());
            if (p == null) { p = new PadState(d); pads.put(d.getId(), p); assignUnclaimedLocked(); }
            p.keyButtons[index] = event.getAction() == KeyEvent.ACTION_UP ? 0f : 1f;
            p.buttons[index] = Math.max(p.keyButtons[index], p.pointerButtons[index]);
            p.timestamp = android.os.SystemClock.uptimeMillis();
            gamepadsJsonCache = "[]";
        }
        return true;
    }

    public boolean handleMotionEvent(MotionEvent e) {
        if (e == null) return false;
        InputDevice d = e.getDevice();
        if (!isController(d)) return false;
        synchronized (lock) {
            refreshDevicesLocked();
            PadState p = pads.get(d.getId());
            if (p == null) { p = new PadState(d); pads.put(d.getId(), p); assignUnclaimedLocked(); }
            readAxes(d, e, p.axes);
            readPointerButtons(d, e, p);
            p.timestamp = android.os.SystemClock.uptimeMillis();
            gamepadsJsonCache = "[]";
        }
        return true;
    }

    /**
     * Some OTG pads are exposed as HID mice. Their physical buttons can be sent
     * through buttonState, or as mouse-style touch ACTION_DOWN/UP, not as gamepad keys.
     * Consume those mouse-button touches so they become gamepad action inputs and do
     * not accidentally click whatever UI happens to be under the pointer.
     */
    public boolean handlePointerButtonTouch(MotionEvent e) {
        if (e == null) return false;
        InputDevice d = e.getDevice();
        if (d == null || !isController(d)) return false;
        int source = e.getSource();
        if ((source & InputDevice.SOURCE_MOUSE) != InputDevice.SOURCE_MOUSE) return false;
        int action = e.getActionMasked();
        if (action != MotionEvent.ACTION_DOWN && action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) return false;
        int changed = e.getActionButton();
        int index = pointerButtonIndex(changed);
        synchronized (lock) {
            refreshDevicesLocked();
            PadState p = pads.get(d.getId());
            if (p == null) { p = new PadState(d); pads.put(d.getId(), p); assignUnclaimedLocked(); }
            if (action == MotionEvent.ACTION_CANCEL) {
                for (int i = 0; i < BUTTON_COUNT; i++) {
                    p.pointerButtons[i] = 0f;
                    p.buttons[i] = p.keyButtons[i];
                }
            } else if (index >= 0) {
                p.pointerButtons[index] = action == MotionEvent.ACTION_DOWN ? 1f : 0f;
                p.buttons[index] = Math.max(p.keyButtons[index], p.pointerButtons[index]);
            } else {
                return false;
            }
            p.timestamp = android.os.SystemClock.uptimeMillis();
            gamepadsJsonCache = "[]";
        }
        return true;
    }

    private static int pointerButtonIndex(int button) {
        switch (button) {
            case MotionEvent.BUTTON_PRIMARY: return 0;   // usual first action / accelerator
            case MotionEvent.BUTTON_SECONDARY: return 1; // usual second action / brake
            case MotionEvent.BUTTON_TERTIARY: return 2;  // usual third action / nitro
            case MotionEvent.BUTTON_BACK: return 8;
            case MotionEvent.BUTTON_FORWARD: return 9;
            default: return -1;
        }
    }

    /** Some OTG pads are exposed as a HID mouse; Android then delivers face/action
     * presses in MotionEvent buttonState instead of KEYCODE_BUTTON_*.
     */
    private static void readPointerButtons(InputDevice d, MotionEvent e, PadState p) {
        int source = e.getSource();
        boolean mouseSource = (source & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
                || (d.getSources() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE;
        if (!mouseSource) return;
        int state = e.getButtonState();
        int[][] mapping = {
                {MotionEvent.BUTTON_PRIMARY, 0},
                {MotionEvent.BUTTON_SECONDARY, 1},
                {MotionEvent.BUTTON_TERTIARY, 2},
                {MotionEvent.BUTTON_BACK, 8},
                {MotionEvent.BUTTON_FORWARD, 9}
        };
        for (int[] item : mapping) {
            int mask = item[0], index = item[1];
            p.pointerButtons[index] = (state & mask) != 0 ? 1f : 0f;
            p.buttons[index] = Math.max(p.keyButtons[index], p.pointerButtons[index]);
        }
    }

    private static int buttonIndex(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_BUTTON_A: return 0;
            case KeyEvent.KEYCODE_BUTTON_B: return 1;
            case KeyEvent.KEYCODE_BUTTON_X: return 2;
            case KeyEvent.KEYCODE_BUTTON_Y: return 3;
            case KeyEvent.KEYCODE_BUTTON_C: return 16;
            case KeyEvent.KEYCODE_BUTTON_Z: return 17;
            case KeyEvent.KEYCODE_BUTTON_1: return 0;
            case KeyEvent.KEYCODE_BUTTON_2: return 1;
            case KeyEvent.KEYCODE_BUTTON_3: return 2;
            case KeyEvent.KEYCODE_BUTTON_4: return 3;
            case KeyEvent.KEYCODE_BUTTON_5: return 4;
            case KeyEvent.KEYCODE_BUTTON_6: return 5;
            case KeyEvent.KEYCODE_BUTTON_7: return 6;
            case KeyEvent.KEYCODE_BUTTON_8: return 7;
            case KeyEvent.KEYCODE_BUTTON_9: return 8;
            case KeyEvent.KEYCODE_BUTTON_10: return 9;
            case KeyEvent.KEYCODE_BUTTON_11: return 10;
            case KeyEvent.KEYCODE_BUTTON_12: return 11;
            case KeyEvent.KEYCODE_BUTTON_13: return 12;
            case KeyEvent.KEYCODE_BUTTON_14: return 13;
            case KeyEvent.KEYCODE_BUTTON_15: return 14;
            case KeyEvent.KEYCODE_BUTTON_16: return 15;
            case KeyEvent.KEYCODE_BUTTON_L1: return 4;
            case KeyEvent.KEYCODE_BUTTON_R1: return 5;
            case KeyEvent.KEYCODE_BUTTON_L2: return 6;
            case KeyEvent.KEYCODE_BUTTON_R2: return 7;
            case KeyEvent.KEYCODE_BUTTON_SELECT: return 8;
            case KeyEvent.KEYCODE_BUTTON_START: return 9;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return 10;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: return 11;
            case KeyEvent.KEYCODE_DPAD_UP: return 12;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 13;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 14;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 15;
            case KeyEvent.KEYCODE_BUTTON_MODE: return 18;
            default: return -1;
        }
    }

    private static float rangeAxis(InputDevice d, MotionEvent e, int axis, float fallback) {
        InputDevice.MotionRange r = d.getMotionRange(axis, e.getSource());
        if (r == null) r = d.getMotionRange(axis);
        if (r == null) return fallback;
        float value = e.getAxisValue(axis);
        float min = r.getMin(), max = r.getMax();
        if (axis == MotionEvent.AXIS_LTRIGGER || axis == MotionEvent.AXIS_RTRIGGER || axis == MotionEvent.AXIS_BRAKE || axis == MotionEvent.AXIS_GAS) {
            if (min < 0f && max > 0f) value = (value - min) / (max - min);
            return clamp(value, 0f, 1f);
        }
        float center = r.getFlat();
        if (Math.abs(value) <= center) return 0f;
        float span = value > 0 ? max - center : center - min;
        return clamp(value / Math.max(Math.abs(span), 0.0001f), -1f, 1f);
    }

    private static boolean hasAxis(InputDevice d, int source, int axis) {
        return d.getMotionRange(axis, source) != null || d.getMotionRange(axis) != null;
    }

    private static void readAxes(InputDevice d, MotionEvent e, float[] a) {
        int source = e.getSource();
        // Android standard joystick ranges. Unknown axis layouts remain available through extra slots.
        a[0] = rangeAxis(d, e, MotionEvent.AXIS_X, a[0]);
        a[1] = rangeAxis(d, e, MotionEvent.AXIS_Y, a[1]);
        a[2] = rangeAxis(d, e, MotionEvent.AXIS_Z, a[2]);
        a[3] = rangeAxis(d, e, MotionEvent.AXIS_RZ, a[3]);
        a[4] = rangeAxis(d, e, MotionEvent.AXIS_LTRIGGER, a[4]);
        a[5] = rangeAxis(d, e, MotionEvent.AXIS_RTRIGGER, a[5]);
        a[6] = rangeAxis(d, e, MotionEvent.AXIS_HAT_X, a[6]);
        a[7] = rangeAxis(d, e, MotionEvent.AXIS_HAT_Y, a[7]);
        // Some generic HID pads expose only RX/RY for the right stick.
        if (!hasAxis(d, source, MotionEvent.AXIS_Z) && hasAxis(d, source, MotionEvent.AXIS_RX)) a[2] = rangeAxis(d, e, MotionEvent.AXIS_RX, a[2]);
        if (!hasAxis(d, source, MotionEvent.AXIS_RZ) && hasAxis(d, source, MotionEvent.AXIS_RY)) a[3] = rangeAxis(d, e, MotionEvent.AXIS_RY, a[3]);
    }

    /** Explicit user reassignment. player is 1 or 2; deviceId is the Android InputDevice ID. */
    public boolean assignDevice(int player, int deviceId) {
        if (player < 1 || player > 2) return false;
        synchronized (lock) {
            refreshDevicesLocked();
            PadState chosen = deviceId < 0 ? null : pads.get(deviceId);
            if (deviceId >= 0 && chosen == null) return false;
            int other = player == 1 ? 1 : 0;
            String chosenDescriptor = chosen == null ? "" : chosen.descriptor;
            if (!chosenDescriptor.isEmpty() && chosenDescriptor.equals(prefs.getString(prefKey(other), ""))) return false;
            prefs.edit().putString(prefKey(player - 1), chosenDescriptor).apply();
            assignUnclaimedLocked();
            return true;
        }
    }

    public String getDevicesJson() {
        synchronized (lock) {
            refreshDevicesLocked();
            JSONArray out = new JSONArray();
            for (PadState p : orderedLocked()) {
                JSONObject o = new JSONObject();
                try { o.put("deviceId", p.deviceId); o.put("name", p.name); o.put("descriptor", p.descriptor); o.put("player", playerForDescriptorLocked(p.descriptor) + 1); } catch (Exception ignored) {}
                out.put(o);
            }
            return out.toString();
        }
    }

    private int playerForDescriptorLocked(String descriptor) {
        if (descriptor != null && descriptor.equals(assignment.get(0))) return 0;
        if (descriptor != null && descriptor.equals(assignment.get(1))) return 1;
        return -1;
    }

    public String getGamepadsJson() {
        synchronized (lock) {
            long now = android.os.SystemClock.uptimeMillis();
            if (!"[]".equals(gamepadsJsonCache) && now - lastJsonAt < 16L) return gamepadsJsonCache;
            refreshDevicesLocked();
            JSONArray out = new JSONArray();
            for (int slot = 0; slot < 2; slot++) {
                String desc = assignment.get(slot);
                PadState found = null;
                if (desc != null && !desc.isEmpty()) for (PadState p : pads.values()) if (desc.equals(p.descriptor)) { found = p; break; }
                if (found == null) continue;
                JSONObject o = new JSONObject(); JSONArray bs = new JSONArray(), ax = new JSONArray();
                for (float b : found.buttons) { JSONObject bo = new JSONObject(); try { bo.put("value", b); bo.put("pressed", b > .5f); bo.put("touched", b > 0f); } catch (Exception ignored) {} bs.put(bo); }
                for (float v : found.axes) { try { ax.put((double) v); } catch (org.json.JSONException ignored) {} }
                try { o.put("index", slot); o.put("deviceId", found.deviceId); o.put("descriptor", found.descriptor); o.put("id", "Android:" + found.descriptor + ":" + found.name); o.put("name", found.name); o.put("connected", true); o.put("mapping", "standard"); o.put("buttons", bs); o.put("axes", ax); o.put("timestamp", found.timestamp); }
                catch (Exception ignored) {}
                out.put(o);
            }
            gamepadsJsonCache = out.toString();
            lastJsonAt = now;
            return gamepadsJsonCache;
        }
    }

    public String loadProfile(int player) {
        if (player < 1 || player > 2) return "{}";
        return prefs.getString(player == 1 ? PROFILE1 : PROFILE2, "{}");
    }

    public boolean saveProfile(int player, String json) {
        if (player < 1 || player > 2 || json == null || json.length() > 8192) return false;
        try {
            JSONObject parsed = new JSONObject(json);
            String key = player == 1 ? PROFILE1 : PROFILE2;
            prefs.edit().putString(key, parsed.toString()).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    public void resetProfile(int player) {
        if (player < 1 || player > 2) return;
        prefs.edit().remove(player == 1 ? PROFILE1 : PROFILE2).apply();
    }

    public boolean vibratePlayer(int player) {
        if (player < 1 || player > 2) return false;
        synchronized (lock) {
            refreshDevicesLocked();
            String desc = assignment.get(player - 1);
            PadState found = null;
            if (desc != null) for (PadState p : pads.values()) if (desc.equals(p.descriptor)) { found = p; break; }
            if (found == null || inputManager == null) return false;
            InputDevice device = inputManager.getInputDevice(found.deviceId);
            if (device == null) return false;
            if (Build.VERSION.SDK_INT < 31) return false; // InputDevice vibrator is API 31+.
            try {
                android.os.Vibrator vibrator = device.getVibrator();
                if (vibrator == null || !vibrator.hasVibrator()) return false;
                vibrator.vibrate(VibrationEffect.createOneShot(180, 110));
                return true;
            } catch (Exception e) { return false; }
        }
    }

    public void dispose() { if (inputManager != null) inputManager.unregisterInputDeviceListener(this); synchronized (lock) { pads.clear(); } }
    @Override public void onInputDeviceAdded(int id) { synchronized (lock) { gamepadsJsonCache = "[]"; lastScanAt = 0L; refreshDevicesLocked(); } }
    @Override public void onInputDeviceRemoved(int id) { synchronized (lock) { pads.remove(id); gamepadsJsonCache = "[]"; lastScanAt = 0L; refreshDevicesLocked(); } }
    @Override public void onInputDeviceChanged(int id) { synchronized (lock) { gamepadsJsonCache = "[]"; lastScanAt = 0L; refreshDevicesLocked(); } }
    private static float clamp(float n, float lo, float hi) { return Math.max(lo, Math.min(hi, n)); }
}
