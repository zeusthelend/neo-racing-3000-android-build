@echo off
setlocal
cd /d "%~dp0"
echo Neo Racing 3000 - Gerando APK de depuracao...
echo.
if not exist "gradlew.bat" (
  echo ERRO: gradlew.bat nao esta nesta pasta.
  echo Extraia o ZIP completo e execute este arquivo na raiz do projeto.
  pause
  exit /b 1
)
call "gradlew.bat" :app:assembleDebug
if errorlevel 1 (
  echo.
  echo A compilacao falhou. Copie a mensagem acima para suporte.
  pause
  exit /b 1
)
echo.
echo APK criado em: app\build\outputs\apk\debug\app-debug.apk
pause
